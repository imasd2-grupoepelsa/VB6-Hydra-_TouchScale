sHost = InputBox("Enter host name or IP address", "Ping (OSICMP Test)", "localhost")

Set WshShell = WScript.CreateObject("WScript.Shell")
Set oPing = WScript.CreateObject("OSICMP.Ping")

For i = 0 To 3
  oPing.Send sHost
  
  If i = 0 Then
    If sHost <> oPing.IP Then s = sHost & " [" & oPing.IP & "]" Else s = sHost
    sOutput = "Pinging " & s & " with " & oPing.PacketSize & " bytes of data:" & vbCrLf & vbCrLf
  End If
  
  sOutput = sOutput & "Reply from " & _
    oPing.IP & ": bytes=" & oPing.PacketSize & " time=" & _
    oPing.RoundTripTime & "ms TTL=" & oPing.TTL & vbCrLf
  
  WshShell.Popup sOutput, 1, "Ping (OSICMP Test)"
  'oPing.Sleep 1000
Next

sOutput = sOutput & vbCrLf & "complete"
WshShell.Popup sOutput, , "Ping (OSICMP Test)"

Set oPing = Nothing
Set WshShell = Nothing