<%
sHost = Request.Form("host")
If sHost = "" Then sHost = "localhost"
Response.Buffer = False
%>
<html>
<head>
<script language="javascript">
<!--//
function formSubmit() {
  if (document.forms[0].host.value == '') {
    alert('enter host name or IP address');
    document.forms[0].host.focus();
    return false;
  }
  return true;
}
//-->
</script>
<title>Ping (OstroSoft ICMP Component - Samples)</title>
</head>

<body>
<font size="+2">Ping</font><br>
(OstroSoft ICMP Component - Samples)

<form action="ping.asp" method="post">
Host <input name="host" size="60" value="<%=sHost%>"> 
<input name="submit" type="submit" value="Ping" onclick="javascript:return formSubmit();">
</form>
<p style="background-color: black; color: white; font-face: Courier; 
  width: 500px; height: 180px; padding: 10px"
<%
If Request.Form("submit") = "Ping" Then
  Response.Write "<hr>"

  Set oPing = Server.CreateObject("OSICMP.Ping")
  
  For i = 0 To 3
    oPing.Send sHost
    
    If i = 0 Then
      If sHost <> oPing.IP Then s = sHost & " [" & oPing.IP & "]" Else s = sHost
      Response.Write "Pinging " & s & " with " & oPing.PacketSize & " bytes of data:<br><br>"
    End If
    
    Response.Write "Reply from " & oPing.IP & ": bytes=" & oPing.PacketSize & _
      " time=" & oPing.RoundTripTime & "ms TTL=" & oPing.TTL & "<br>"
    
    oPing.Sleep 1000
  Next
  
  Response.Write "<br>complete"
  
  Set oPing = Nothing
  Set WshShell = Nothing
End If
%>
</body>
</html>
