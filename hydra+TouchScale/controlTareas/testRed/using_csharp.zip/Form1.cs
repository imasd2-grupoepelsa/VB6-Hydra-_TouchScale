using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace using_csharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.TextBox txtHost;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtOutput;
		private System.Windows.Forms.Button cmdPing;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtHost = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.txtOutput = new System.Windows.Forms.TextBox();
			this.cmdPing = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txtHost
			// 
			this.txtHost.Location = new System.Drawing.Point(48, 8);
			this.txtHost.Name = "txtHost";
			this.txtHost.Size = new System.Drawing.Size(232, 20);
			this.txtHost.TabIndex = 0;
			this.txtHost.Text = "localhost";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(27, 16);
			this.label1.TabIndex = 1;
			this.label1.Text = "Host";
			// 
			// txtOutput
			// 
			this.txtOutput.Location = new System.Drawing.Point(8, 72);
			this.txtOutput.Multiline = true;
			this.txtOutput.Name = "txtOutput";
			this.txtOutput.Size = new System.Drawing.Size(272, 168);
			this.txtOutput.TabIndex = 2;
			this.txtOutput.Text = "";
			// 
			// cmdPing
			// 
			this.cmdPing.Location = new System.Drawing.Point(112, 40);
			this.cmdPing.Name = "cmdPing";
			this.cmdPing.Size = new System.Drawing.Size(64, 23);
			this.cmdPing.TabIndex = 3;
			this.cmdPing.Text = "Ping";
			this.cmdPing.Click += new System.EventHandler(this.cmdPing_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 245);
			this.Controls.Add(this.cmdPing);
			this.Controls.Add(this.txtOutput);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtHost);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void cmdPing_Click(object sender, System.EventArgs e)
		{
			OSICMP.PingClass oPing = new OSICMP.PingClass();
			String s = "";
			
			try 
			{
				for (int i = 0; i < 4; i++) 
				{
					oPing.Send(txtHost.Text, 1000, 32);
			    
					if (i == 0) 
					{
						if (txtHost.Text != oPing.IP) 
							s = txtHost.Text + " [" + oPing.IP + "]";
						else 
							s = txtHost.Text;
						txtOutput.Text = "Pinging " + s + " with " + oPing.PacketSize + " bytes of data:\r\n\r\n";
					}
			    
					txtOutput.Text = txtOutput.Text + "Reply from " + oPing.IP + ": bytes=" + oPing.PacketSize + 
						" time=" + oPing.RoundTripTime + "ms TTL=" + oPing.TTL + "\r\n";
			    
					oPing.Sleep(1000);
				}
	  
				txtOutput.Text = txtOutput.Text + "\r\ncomplete";
			}
			catch (Exception ex)
			{
				txtOutput.Text = "Error: " + ex.Message;
			}
}
	}
}
